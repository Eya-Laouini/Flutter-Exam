class Department {
  final int id;
  final String name;

  Department({required this.id, required this.name});
}
