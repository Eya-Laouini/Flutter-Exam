import 'package:flutter/material.dart';

class TotalAbsencesPage extends StatelessWidget {
  final List<Map<String, dynamic>> absences;
  final String studentName;

  TotalAbsencesPage({required this.absences, required this.studentName});

  @override
  Widget build(BuildContext context) {
    double totalAbsences = absences.fold(
      0,
          (sum, absence) => sum + (absence['nha'] as double? ?? 0.0),
    );

    return Scaffold(
      appBar: AppBar(
        title: Text('Total Absences for $studentName'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Total Absences: $totalAbsences hours',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            // Optionally, add more details or a list of absences here
          ],
        ),
      ),
    );
  }
}
